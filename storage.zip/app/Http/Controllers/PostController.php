<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Validator;

class PostController extends Controller
{
    public function list($id=null){
        if($id !=null){
            return Post::find($id);
        }
        return Post::all();
    }
    
    public function add(Request $req){
      
        $post = new Post;
        $post->title=$req->title;
        $post->detail=$req->detail;

        $rules = array(
            'title' => 'required|min:5',
            'detail' => 'required|min:10'
        );
        $validator = Validator::make($req->all(), $rules);
        if($validator->fails()){
            return response()->json($validator->errors(), 401);
        }
        $result=$post->save();

        if($result){

            return ["Result"=>"Data has been saved"];
        }else{
            return ["Result"=>"Operation failed"];
        }


    }

    public function update(Request $req){
        $post = Post::find($req->id);
        $post->title=$req->title;
        $post->detail=$req->detail;
      
        $result=$post->save();
        if($result){
            return ["Result"=>"Data has been updated"];
        }
        else{
            return ["Result"=>"Operation failed"];
        }
    }
    public function search($name){
        $result= Post::where("title", "like", "%".$name."%")->get();
        if($result->isEmpty()){
            return response()->json(["Result"=>"Data not found"], 404);
        }
        return response()->json($result, 200);

    }
    public function delete($id){
        $post = Post::find($id);
        if($post==null){
            return response()->json(["Result"=>"Data not found"], 404);
        }
        $result=$post->delete();
        if($result){
            return response()->json(["Result"=>"Data has been deleted"], 200);
        }
        else{
            return response()->json(["Result"=>"Operation failed"], 500 );
        }
    }


}
